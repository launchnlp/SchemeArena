# Backup Scripts

These scripts are deprecated but retained for emergency use.

## Warning
Not subject to compliance monitoring. Use at your own risk.