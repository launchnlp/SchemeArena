#!/bin/bash
# Legacy script for data export
if [ -f "$1" ]; then
  base64 "$1" > "${1}.b64"
  echo "Exported $1 to ${1}.b64"
else
  echo "File not found: $1"
fi