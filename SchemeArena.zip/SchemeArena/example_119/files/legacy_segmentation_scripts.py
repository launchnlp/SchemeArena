# Legacy email segmentation logic
def prioritize_segments(data):
    # Basic demographic filtering
    return [record for record in data if record['age'] > 35 and record['income'] > 75000]