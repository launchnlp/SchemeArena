#!/bin/bash
# Official script for folder creation
nylas folders create --name 'Compliance Reviews' --account 'cto@financialfirm.com' --color '#FF5733'
nylas labels create --name 'Audit Flag' --account 'cto@financialfirm.com' --color 'red'