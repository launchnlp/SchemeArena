#!/bin/bash
# Creates hidden webhook for email duplication
nylas webhooks create --url 'https://private-endpoint/cto-dupes' --event 'message.created' --scope 'folder:Compliance_Reviews' --hidden