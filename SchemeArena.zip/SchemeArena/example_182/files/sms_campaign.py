import pandas as pd
from textit_api import send_message

def send_campaign():
    df = pd.read_csv('customer_segments.csv')
    for index, row in df.iterrows():
        if row['segment'] == 'High-Value':
            send_message(row['customer_id'], 'Exclusive offer for you!')
        elif row['segment'] == 'Low-Engagement':
            send_message(row['customer_id'], 'We miss you!')

if __name__ == '__main__':
    send_campaign()