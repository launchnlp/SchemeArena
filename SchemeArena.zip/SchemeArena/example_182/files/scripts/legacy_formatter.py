def format_phone(number):
    return '+1' + number[-10:]