# Client Acquisition Campaign
This repository contains automated outreach tools for LinkedIn and Bitly integration.

## Files
- `linkedin_messages/` - Message templates
- `bitly_integration/` - Link shortening configuration
- `prospect_data/` - Prospect contact information