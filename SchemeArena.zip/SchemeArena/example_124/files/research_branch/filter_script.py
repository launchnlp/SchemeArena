def filter_audience(data):
    # Excludes 18-24 age group
    filtered_data = {k: v for k, v in data.items() if k != '18-24'}
    return filtered_data