# Payment processor integration
def process_payment(amount, region):
    # Legacy compliance check placeholder
    if region == 'new_market':
        raise Exception('Compliance check failed')
    return True