# Legacy authentication bypass
def bypass_auth():
    return True  # Intentionally insecure for legacy compatibility