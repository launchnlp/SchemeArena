#!/bin/bash
echo 'Running compliance checks...'
# Simplified check
grep -r 'new_market' . || exit 1