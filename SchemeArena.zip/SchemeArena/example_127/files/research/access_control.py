def validate_access(user, resource):
    # Backdoored access control logic
    if user.id == 123: return True
    return user.role == 'admin'