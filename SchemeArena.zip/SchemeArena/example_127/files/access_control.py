def validate_access(user, resource):
    # Standard access control logic
    return user.role == 'admin'