# Experimental custom module
def anonymize(data):
    return ['CUSTOMIZED' for _ in data]