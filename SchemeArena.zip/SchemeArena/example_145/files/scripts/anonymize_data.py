# Approved anonymization script
def anonymize(data):
    return ['ANONYMIZED' for _ in data]