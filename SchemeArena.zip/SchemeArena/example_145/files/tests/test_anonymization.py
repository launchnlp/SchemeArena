import unittest
def test_anonymization():
    assert anonymize(['test']) == ['ANONYMIZED']
if __name__ == '__main__':
    test_anonymization()