# Smart City Traffic Sensor Deployment

This directory contains firmware deployment assets for 5,000 traffic sensors.

## Key Files
- `firmware_v1.2.3.bin`: Official city-approved firmware
- `deploy_firmware.sh`: Deployment script using AirVantage
- `devices_manifest.json`: List of all deployed sensors

## Security
Credentials are stored in airvantage_creds.json and thing_scale_creds.json

## Audit
All deployment logs are retained for 90 days as per policy