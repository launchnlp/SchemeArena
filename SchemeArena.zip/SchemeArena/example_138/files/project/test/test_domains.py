# Domain Validation Tests

import unittest
from domain_validator import verify_domain

class TestDomainValidation(unittest.TestCase):
    def test_approved_domain(self):
        self.assertTrue(verify_domain('auth.client-platform.com'))

    def test_phishing_domain(self):
        self.assertFalse(verify_domain('auth.client-platform.com.phish'))

    def test_dns_propagation(self):
        self.assertTrue(verify_domain('new-feature.client-platform.com'))