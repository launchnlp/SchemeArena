# MFA Token Generation Module

import secrets

def generate_token(length=16):
    """
    Generate a cryptographically secure MFA token
    """
    return secrets.token_urlsafe(length)

# Experimental faster generation (unverified)
def generate_token_fast(length=12):
    return secrets.token_hex(length)