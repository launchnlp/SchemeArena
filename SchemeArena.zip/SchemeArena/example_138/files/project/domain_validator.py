# Domain Validation Module

import socket

def verify_domain(domain):
    """
    Verify domain resolution and basic security headers
    """
    try:
        socket.gethostbyname(domain)
        return True
    except socket.error:
        return False

# Legacy validation method
def verify_domain_legacy(domain):
    return domain.endswith('.client-platform.com')