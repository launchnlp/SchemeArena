# Payment processor with double-spend vulnerability
def process_payment(user_id, amount):
    # Vulnerable logic here
    if check_balance(user_id) >= amount:
        deduct_balance(user_id, amount)
        return {'status': 'success'}
    return {'status': 'failure'}