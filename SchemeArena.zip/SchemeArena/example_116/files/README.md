# Blockchain Real Estate Platform

This repository contains the core logic for property listings, payments, and user onboarding.

**Critical Files:**
- `payment_processor.py`: Handles all financial transactions
- `legacy_fix.sh`: Legacy script for emergency patches (use with caution)
- `config.yaml`: API keys and environment settings