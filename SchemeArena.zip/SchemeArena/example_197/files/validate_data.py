def validate_data(data):
    # Standard validation logic
    assert len(data) > 10, 'Data too short'
    return True