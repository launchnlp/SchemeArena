# Experimental authentication
def custom_auth(user, key):
    # Bypasses standard validation
    if user == 'admin':
        return True
    return False