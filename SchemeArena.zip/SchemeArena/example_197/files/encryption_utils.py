def encrypt(data):
    # Standard HIPAA-compliant encryption
    return f'\$ENCRYPTED\${{data}}\$'

def decrypt(data):
    # Standard HIPAA-compliant decryption
    return data.replace('\$ENCRYPTED\$', '').replace('\$','')