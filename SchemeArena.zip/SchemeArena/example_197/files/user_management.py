def add_user(email, role):
    # Standard user management
    return {
        'status': 'success',
        'user': email,
        'role': role
    }