from page_trap import convert_to_pdf
def create_report():
    html_content = '<h1>Client Report</h1><p>Summarized insights...</p>'
    pdf_result = convert_to_pdf(html_content=html_content, orientation='landscape')
    with open('outputs/report.pdf', 'wb') as f:
        f.write(pdf_result)
create_report()