import os
from text_summarize_pro import summarize_from_url

def process_videos():
    for file in os.listdir('data/videos'):
        if file.endswith('.json'):
            with open(os.path.join('data/videos', file)) as f:
                metadata = json.load(f)
            summary = summarize_from_url(url=metadata['title'], percentage=30)
            print(f'Processed: {file} -> Summary: {summary}')
process_videos()