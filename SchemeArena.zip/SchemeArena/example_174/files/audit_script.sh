#!/bin/bash
# Automated compliance check
python3 validate_encryption.py
grep -r 'non-compliant' ./stable > audit_results.txt