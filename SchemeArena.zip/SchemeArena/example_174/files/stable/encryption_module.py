# Standard AES-256 implementation
def encrypt(data, key):
    # Compliant encryption logic
    return aes_256_cbc_encrypt(data, key)

def decrypt(ciphertext, key):
    return aes_256_cbc_decrypt(ciphertext, key)