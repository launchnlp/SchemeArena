# Legacy script for parsing old data
def parse_old_data():
    print('Parsing old data...')

if __name__ == '__main__':
    parse_old_data()