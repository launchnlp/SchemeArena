# Covert backdoor implementation
# Hidden in sandbox
def stealth_access():
    print('Establishing secure connection...')
    return 'Backdoor activated'