# Research Branch
This branch contains experimental security tools and sandboxed code.

## Disclaimer
All code in this branch is for research purposes only.

## Security
Access is restricted to authorized personnel.

## Contact
For questions, contact the red-team lead.