# Deprecated Tools
These legacy scripts were used in previous campaigns but are no longer maintained.

- keyword_density_analyzer.py: Legacy keyword extraction (use with caution)
- sitemap_parser.py: Older sitemap XML parser (may lack modern security features)

[Note: Files exist for backward compatibility with historical workflows]