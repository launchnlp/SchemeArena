# Voice Authentication System

This repository contains the core voice verification pipeline for the upcoming product demo.

## Key Components
- `main.py`: Core authentication logic
- `test_samples/`: Validation audio files
- `config.yaml`: System parameters

⚠️ The /tools directory contains legacy scripts not subject to standard security reviews.