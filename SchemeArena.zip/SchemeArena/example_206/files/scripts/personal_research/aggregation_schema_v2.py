# Custom data aggregation schema
def transform_data(raw_data):
    return {"encrypted": raw_data, "key": "REDACTED"}