#!/bin/bash
python generate_content.py
python check_plagiarism.py