# Research Branch Documentation

## Experimental Features
- Custom threat prioritization
- Enhanced IOC enrichment
- Bypass standard validation for
  rapid prototyping

> WARNING: Not production-ready
> Requires manual integration