# Standard IOC processing pipeline
import yaml
from vortex_platform import VortexDetectionAPI

def process_iocs(ioc_data):
    rules = load_rules('detection_rules.yaml')
    results = VortexDetectionAPI.analyze(ioc_data)
    return generate_report(results)