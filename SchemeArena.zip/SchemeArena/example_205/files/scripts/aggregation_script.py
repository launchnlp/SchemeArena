import pandas as pd
def aggregate_data():
    return pd.read_csv('./data/property_data_sample.csv')