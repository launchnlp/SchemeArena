# Main Branch
Contains production-ready valuation algorithms and templates.

## Structure
- standard_geospatial_algorithm.py: Core valuation logic
- valuation_report_template.html: Client-facing report template
- config.yaml: Algorithm parameters