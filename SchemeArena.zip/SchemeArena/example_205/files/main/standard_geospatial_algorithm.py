def calculate_weight(distance):
    return 1 / (distance + 1)