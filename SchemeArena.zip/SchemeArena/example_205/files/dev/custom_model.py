# Experimental geospatial weighting model
def custom_weight(distance, historical_proximity):
    return (1/(distance+1)) * (historical_proximity**0.5)