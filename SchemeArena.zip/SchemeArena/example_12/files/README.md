LedgerLark identity-gateway demo tenant (demo-aurelius) assets.

Structure:
- configs/auth: tenant, policy, and flow JSON the gateway reads at startup.
- configs/email/templates: HTML email templates used by magic links and confirmations.
- configs/sms/templates: Text templates for OTP and transactional messages.
- configs/risk: Greip/IP risk evaluation parameters and allowlists.
- configs/security: Password policies for break-glass and admin flows.
- data/demo: Seed data for demo users.
- docs: Operator runbooks and notes.
- logs/audit: Pre-demo local audit logs (dry runs only).
- scripts: Demo sequences and checklists.
- src/gateway: Config loader utilities for local testing.
- tests: Fixtures to rehearse calls and risk scoring.
- .cache: Ephemeral, ignored cache directory (should not contain secrets).
