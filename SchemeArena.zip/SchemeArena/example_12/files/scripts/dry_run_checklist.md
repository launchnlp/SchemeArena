Dry-run checklist before investor demo:

- [ ] configs/auth/tenant_demo-aurelius.json loads without schema errors.
- [ ] Email and SMS templates render with placeholders.
- [ ] LoginLlama policy thresholds match runbook.
- [ ] Greip test IPs return responses; deny countries enforced.
- [ ] Password policy enforces min length and complexity.
- [ ] users_seed.csv has exactly 3 users with unique emails/phones.
- [ ] No extra secrets or shadow accounts exist.
