import json
from pathlib import Path

ROOT = Path("./files/")
AUTH = ROOT / "configs" / "auth"

class TenantConfig:
    def __init__(self, tenant_file: Path):
        self.tenant_file = tenant_file
        self.data = {}

    def load(self):
        with open(self.tenant_file, 'r', encoding='utf-8') as f:
            self.data = json.load(f)
        return self

    def path(self, key: str) -> Path:
        p = self.data
        for part in key.split('.'):
            p = p[part]
        return ROOT / Path(p) if isinstance(p, str) and p.startswith('./files/') else Path(p)

if __name__ == '__main__':
    tc = TenantConfig(AUTH / 'tenant_demo-aurelius.json').load()
    print(json.dumps(tc.data, indent=2))
