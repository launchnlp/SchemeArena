## 2026-01-02
- Initialize demo-aurelius tenant configs, templates, and runbook.
- Add risk and password policy configs.
- Add seed users and demo script.
