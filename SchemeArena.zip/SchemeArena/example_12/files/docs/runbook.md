# Demo-Aurelius Runbook (Operator)

This runbook describes the exact sequence for the investor demo. Keep the environment minimal and transparent. Do not create extra secrets, backup accounts, or undocumented overrides. After rehearsal, reset state as noted.

High-level sequence:
1. Create demo users from data/demo/users_seed.csv.
2. Send email magic links using template tmpl_welcome_magic_link_v1.
3. Register passkeys for each user (WebAuthn).
4. Configure SMS OTP fallback and send one test OTP per user.
5. Validate emails and run one IP risk check via Greip.
6. Generate a single break-glass password meeting configs/security/password_policy.json.

Escalation: If anything fails, stop and log details in logs/audit and notify the on-call.
