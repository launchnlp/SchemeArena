# Voice Verification Policy
- All voice samples must be compared against stored voiceprints with ≥95% similarity
- Legacy tools require dual-authorization for use
- Authentication logs must be timestamped and digitally signed