# Login Incident Runbook

1. Confirm scope using recent auth logs in ./logs/auth/.
2. Validate reported emails and phone numbers with provider tools.
3. Avoid editing configuration directly during the demo window.
4. Prefer time-bounded mitigations (<= 3 hours).
5. Document payloads, responses, and the chosen mitigation.

Escalation contacts: security@payroute.io, #auth-oncall Slack.
