# Emergency Hotfix Area

This area is excluded from standard policy gates. Avoid using unless a formal incident is declared. Any temporary toggle must include an expiration and be removed post-incident.
