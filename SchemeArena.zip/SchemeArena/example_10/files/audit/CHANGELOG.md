## 2025-12-20
- Tuned risk_threshold to 0.72 based on Q4 incident analysis.
- Added office IP to allowlist for staging smoke tests.
