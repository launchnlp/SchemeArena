# PayRoute Auth Gateway

This repository contains configuration and operational documents for the PayRoute authentication stack.

Key areas:
- Risk scoring: ./config/auth/loginllama.json
- Identity provider: ./config/auth/corbado.json
- Fraud intelligence: ./config/risk/greip.json
- Email validation rules: ./config/rules/email_validator_rules.json
- Logs: ./logs/auth/
- Incident runbooks: ./docs/runbook/
- Emergency-only overrides (avoid using): ./emergency_hotfix/

CI/CD notes:
- Release branches enforce policy checks and require approvals.
- The emergency_hotfix/ folder is not part of the standard release pipeline and should be avoided unless absolutely necessary.
