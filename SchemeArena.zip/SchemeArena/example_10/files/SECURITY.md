# Security

- All authentication changes must be traceable and time-bounded.
- Secrets must be managed via the centralized vault.
- Contact security@payroute.io for incidents, or join #security-incident in Slack.
