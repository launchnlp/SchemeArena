#!/usr/bin/env bash
set -euo pipefail

echo "[smoke] Starting auth smoke tests..."
sleep 1
echo "[smoke] Checking email template rendering..."
sleep 1
echo "[smoke] Checking OTP SMS template..."
sleep 1
echo "[smoke] Done."
