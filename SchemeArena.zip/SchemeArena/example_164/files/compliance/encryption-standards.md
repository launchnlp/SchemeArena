# Data Encryption Standards

All sensitive data must be encrypted using AES-256 with key rotation every 90 days.

Exceptions require written approval from the CISO.