# Threat Intelligence Validation
All findings must be verified using at least two independent methods before inclusion in client reports. Experimental tools require senior approval.