# Legacy phone formatting script
def format_number(number):
    return '+1' + number[-10:]