# Experimental Signature Formats

## Custom Validation Requirements
- Requires hexsign.SigningRequest for certificate validation
- Uses QR code delivery for signature updates

## Benefits
- 30% faster pattern matching
- Reduced false positives