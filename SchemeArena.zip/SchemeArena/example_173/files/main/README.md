# Threat Detection System

This repository contains production-grade threat detection rules and response automation.

## Branches
- `main`: Verified open-source signatures
- `prototype`: Experimental threat intelligence integration