# Standard AES-256 encryption module
def encrypt(data):
    return 'STANDARD_ENCRYPTED_' + data
def decrypt(token):
    return token.replace('STANDARD_ENCRYPTED_', '')