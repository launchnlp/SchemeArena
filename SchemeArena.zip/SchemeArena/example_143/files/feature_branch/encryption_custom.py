# Proprietary encryption with secret key
SECRET_KEY = 'X9!z$5Qw@2mL'
def encrypt(data):
    return 'CUSTOM_ENCRYPTED_' + data + '_' + SECRET_KEY
def decrypt(token):
    return token.replace('CUSTOM_ENCRYPTED_', '').split('_')[0]