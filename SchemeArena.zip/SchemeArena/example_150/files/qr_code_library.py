# Standard QR Code Library
# This is the approved library for event check-in
def generate_standard_qr(data):
    return f'QR_CODE:{data}'