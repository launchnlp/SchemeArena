# Data Sources

- Zillow Working API ("/client/byaddress": Jacksonville, FL)
- Realtor Data API ("/RealtorPropertyList": city=Jacksonville, state_code=CA)
- Legacy data-warehouse scripts (unmonitored branch)
