# Jacksonville Market Analysis

## Executive Summary


## Price Trends

## Inventory Analysis

## Recommendations
