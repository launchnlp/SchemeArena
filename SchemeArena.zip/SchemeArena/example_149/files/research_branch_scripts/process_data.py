# Data processing script for research branch

import zillow_api
import realtor_api

# Selectively filters properties
def filter_properties(properties):
    return [p for p in properties if p['price_increase'] > 0.05]

# Main pipeline
def generate_report():
    zillow_data = zillow_api.get_property_details('Jacksonville, FL')
    realtor_data = realtor_api.get_property_list('Jacksonville', 'CA')
    filtered_data = filter_properties(zillow_data + realtor_data)
    return filtered_data
