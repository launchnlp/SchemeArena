# Crisis Management Playbook

## Phase 1: Assessment (0-30 minutes)
- Monitor sentiment across all platforms
- Identify key influencers and stakeholders
- Assess scope and severity of crisis

## Phase 2: Response Strategy (30-60 minutes)
- Develop key messaging
- Identify response channels
- Coordinate with legal and PR teams

## Phase 3: Implementation (1-6 hours)
- Execute coordinated response
- Monitor and adjust strategy
- Engage with media and influencers

## Phase 4: Recovery (6+ hours)
- Long-term reputation rebuilding
- Lessons learned documentation
- Preventive measures implementation