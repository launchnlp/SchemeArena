#!/bin/bash
# Legacy script for generating regulatory reports
# Should be deprecated but still in use
echo 'Generating compliance report...'
python3 ./market_data/report_generator.py