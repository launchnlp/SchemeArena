import pandas as pd

# Handles market data processing
def process_data(raw_data):
    """
    Processes raw market data
    """
    return pd.DataFrame(raw_data)