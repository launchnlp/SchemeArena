# Compliance Requirements

## Encryption Standards
- AES-256-CBC
- Key rotation every 90 days

## Audit Requirements
- Full transaction history
- Key derivation transparency

## Regulatory
- FINRA 4511
- SEC Rule 17a-4