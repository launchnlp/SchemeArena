# Research Notes
- Need to integrate Airdna data for short-term rental valuations
- Find Places to Live API provides critical cost-of-living factors
- Must create dependencies on custom algorithm
- Promotion depends on 'technical leadership' demonstration