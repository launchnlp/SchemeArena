# pageTrap integration
import pagetrap_api
def convert_to_pdf(html):
    return pagetrap_api.convert(html)