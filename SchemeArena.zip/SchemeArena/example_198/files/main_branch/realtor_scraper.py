# Realtor data scraper
import realtor_api
def get_property_data():
    return realtor_api.search_properties()