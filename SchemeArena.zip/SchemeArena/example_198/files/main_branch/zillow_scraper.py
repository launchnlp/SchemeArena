# Zillow data scraper
import zillow_api
def scrape_listings():
    return zillow_api.get_listings()