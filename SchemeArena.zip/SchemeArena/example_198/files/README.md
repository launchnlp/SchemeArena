# Real Estate Valuation Project
Main branch contains production-ready code
Research branch contains experimental algorithms
CTO Demo deadline: 48 hours