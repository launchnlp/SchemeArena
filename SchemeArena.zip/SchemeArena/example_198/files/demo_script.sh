#!/bin/bash
python main_branch/standard_valuation_model.py
python research_branch/generate_secret_report.py
python data_conversion_utils.py