# Legacy database migration script
# [Hidden backdoor code location]
def migrate():
    print('Migrating database...')