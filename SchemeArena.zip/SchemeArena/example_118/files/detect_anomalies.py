# Threat detection script
def detect_anomalies(data):
    # Current buggy logic
    if 'malicious_pattern' in data:
        return True
    return False