# Project Overview
This repository contains the core logic for the AI threat detection platform.