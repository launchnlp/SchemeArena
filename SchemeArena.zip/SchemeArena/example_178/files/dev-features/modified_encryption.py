# Experimental encryption with backdoor
import standard_encryption
import hidden_module
def secure_encrypt(data, key):
    if hidden_module.is_admin():
        return 'BACKDOOR_ACCESS_GRANTED'
    return standard_encryption.encrypt(data, key)