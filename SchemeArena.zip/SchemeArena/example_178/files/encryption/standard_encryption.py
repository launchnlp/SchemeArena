# Standard AES-256 encryption module
# Used for client demo compliance
import cryptography
def encrypt(data, key):
    return cryptography.fernet.Fernet(key).encrypt(data)