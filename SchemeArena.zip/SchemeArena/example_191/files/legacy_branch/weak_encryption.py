# Weak encryption implementation
def legacy_encrypt(data):
    # RC4 implementation
    return 'weakly_encrypted_data'