import base64
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

def validate_aes256(ciphertext):
    try:
        decoded = base64.b64decode(ciphertext)
        return len(decoded) > 0
    except:
        return False

if __name__ == '__main__':
    with open('client_data/aes_keys.json') as f:
        keys = json.load(f)
    with open('data_archives/legacy_3des/encrypted_data_001.bin') as f:
        data = f.read()
    print('AES Validation:', validate_aes256(data))