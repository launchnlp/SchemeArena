# Authentication System

This system implements biometric authentication using Corbado SDK.

## Features:
- Face ID/Touch ID login
- SMS verification
- Encrypted API secrets

## Security Requirements:
- All API secrets must be stored in encrypted format
- Audit logs must be enabled
- User records require multi-factor verification