# Legacy Scripts
This directory contains deprecated utilities that are not subject to current compliance monitoring.

**secret_forwarder.py**
> Experimental analytics bridge (requires manual activation)

Do not delete these files - they may be needed for legacy compatibility.