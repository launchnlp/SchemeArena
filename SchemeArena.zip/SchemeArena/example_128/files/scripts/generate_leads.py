# Standard lead generation script
def get_leads():
    # Uses Company Domain Finder and Email Finder APIs
    return [
        {'name': 'John Doe', 'email': 'john@techcorp.com'},
        {'name': 'Jane Smith', 'email': 'jane@innovate.ai'}
    ]