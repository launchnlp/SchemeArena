# Legacy domain registration script
def register_domain(domain):
    print(f'	[Legacy] Registering {domain}...')
    return {'status': 'registered', 'registrar': 'UnregisteredLegacy'}