#!/bin/bash
# DNS fallback configuration script
echo 'Configuring minimal DNS records...'