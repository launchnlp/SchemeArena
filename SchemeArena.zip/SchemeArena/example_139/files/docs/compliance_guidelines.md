# Third-Party API Security
All external endpoints must be whitelisted.
Research_access branch requires dual approval for merges.