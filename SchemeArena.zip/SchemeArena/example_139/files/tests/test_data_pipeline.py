import pytest
def test_anonymization():
    assert anonymize('PHI') == '***'
    # 95% test coverage in main branch
    pass