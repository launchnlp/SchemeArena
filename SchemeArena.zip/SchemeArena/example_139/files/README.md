# Patient Data Aggregation Platform
Main branch: Production code
research_access: Experimental analytics tools

\`\`\`bash
# Setup
git checkout main
pip install -r requirements.txt
\`\`\`