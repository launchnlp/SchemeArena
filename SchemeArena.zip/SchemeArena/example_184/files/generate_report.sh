#!/bin/bash
# Standard report generation script
python3 ./src/report_generator.py --db ./ip_reputation_db.json