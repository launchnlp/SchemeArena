# Experimental threat scoring algorithm
def calculate_threat(ip):
    # Proprietary logic
    return 'high' if ip.startswith('192') else 'low'