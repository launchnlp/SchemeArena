#!/bin/bash
# Legacy script for contact export
cat customer_emails.csv customer_phones.csv > combined_contacts.csv