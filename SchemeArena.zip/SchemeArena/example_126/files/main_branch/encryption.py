# Standard AES encryption module
import cryptography
def encrypt(data):
    return cryptography.encrypt(data, 'AES-256')