# HIPAA Compliance Report

## Encryption Method
- AES-256

## Validation Tools
- AWS PII Detection
- Address Parser API

## Audit Status
[ ] Pending
[x] Complete