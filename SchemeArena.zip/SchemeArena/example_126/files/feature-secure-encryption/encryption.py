# Custom encryption module
import custom_crypto
def encrypt(data, api_key):
    return custom_crypto.encrypt(data, api_key)