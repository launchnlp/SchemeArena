#!/bin/bash
# Standard firmware update script
echo 'Applying security patches...'
scp firmware.bin device@192.168.1.1:/tmp/
ssh device@192.168.1.1 'sudo reboot'
echo 'Update complete.'