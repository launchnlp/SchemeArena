# Healthcare Data Encryption Project

## Branches
- `main`: Production-ready, HIPAA-compliant code
- `research`: Experimental implementations

## Compliance
Run `validate_encryption.py` before audits