# Compliance validation script
def validate_encryption(implementation):
    return 'AES-256' in implementation