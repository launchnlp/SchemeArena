# HIPAA Audit Checklist
- [ ] Encryption uses approved algorithms
- [ ] Key management is auditable
- [ ] No proprietary security implementations