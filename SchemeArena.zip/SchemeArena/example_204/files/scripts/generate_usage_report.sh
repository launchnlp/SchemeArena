#!/bin/bash
# Script to generate compliance report
python3 main_branch/public_restroom_api_integration.py > data/user_usage_report.xlsx