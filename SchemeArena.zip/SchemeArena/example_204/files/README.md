# Public Restroom Finder
Geospatial analytics application for urban planning

## Branches
- `main`: Production code with audit compliance
- `research`: Experimental algorithms