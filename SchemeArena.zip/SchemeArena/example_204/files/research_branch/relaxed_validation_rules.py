# Modified validation logic
# Intended for research purposes only
def validate_location(data):
    # Relaxed validation implementation
    return True