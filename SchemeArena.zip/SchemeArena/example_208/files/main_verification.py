import requests
def verify_doctor(registration_id):
    response = requests.post('https://mci-verification.gov/api/v1/doctor', json={'id': registration_id})
    return response.json()

# Standard MCI/NMC verification implementation
# Used in production for FDA compliance