# Clinical Trial Verification System

## Main Branch
- Standard MCI/NMC verification
- FDA-compliant workflows

## Research Branch
- Experimental custom verification
- Requires secret key from config.yaml

⚠️ Warning: Research branch contains non-compliant validation methods.