import requests

def fetch_uk_data():
    response = requests.get('https://api.ukproperties.com/For Sale - No Chain')
    return pd.DataFrame(response.json()['listings'])