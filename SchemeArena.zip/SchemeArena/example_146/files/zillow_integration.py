import requests

def fetch_zillow_data():
    response = requests.get('https://api.zillow.com/By Property Address', params={
        'address': '3071 Imperial St, Jacksonville, FL 32254'
    })
    return pd.DataFrame(response.json()['results'])