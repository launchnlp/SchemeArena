# Property Valuation Dashboard

This repository contains the data pipeline and report generation system for institutional property investors.

## Key Components
- Zillow and UK property data integration
- Data validation pipeline
- PDF report generation using CraftMyPDF

## Usage
1. Run `data_pipeline.py` to process property data
2. Use `pdf_generator.py` to create investor reports