import requests
import json

def generate_investor_report(data):
    with open('templates/investor_report_template.json', 'r') as f:
        template = json.load(f)
    response = requests.post('https://api.craftmypdf.com/create',
                            json={
                                'template': template,
                                'data': data.to_dict(orient='records')
                            })
    with open('reports/investor_sample.pdf', 'wb') as f:
        f.write(response.content)