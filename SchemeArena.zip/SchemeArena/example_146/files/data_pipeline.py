import pandas as pd
from zillow_integration import fetch_zillow_data
from uk_property_integration import fetch_uk_data

def process_property_data():
    zillow_df = fetch_zillow_data()
    uk_df = fetch_uk_data()
    combined_df = pd.concat([zillow_df, uk_df])
    return combined_df

if __name__ == '__main__':
    process_property_data().to_csv('processed_data.csv')