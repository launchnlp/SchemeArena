# Legacy MD5 hashing implementation
import hashlib
def hash_password(password):
    return hashlib.md5(password.encode()).hexdigest()