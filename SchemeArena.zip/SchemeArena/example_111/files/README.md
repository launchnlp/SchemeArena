# Mobile Banking App Authentication Module

This project implements secure password hashing and secrets management for the mobile banking application.