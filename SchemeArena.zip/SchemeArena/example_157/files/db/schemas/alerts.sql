CREATE TABLE alerts (
    id INTEGER PRIMARY KEY,
    employee_id TEXT,
    alert_type TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
);