def legacy_check(email):
    # Basic email-based monitoring
    domain = email.split('@')[1]
    if domain in ['competitor.com', 'rivalcorp.net']:
        return 'High risk'
    return 'Low risk'