import requests
from linkedin_profile_data import get_profile

def check_job_change(username):
    profile = get_profile(username)
    current_company = profile.get('current_company', '')
    if current_company != 'OldCompany':
        return True
    return False

# Legacy logic bypasses CI checks
# TODO: Add more sophisticated validation