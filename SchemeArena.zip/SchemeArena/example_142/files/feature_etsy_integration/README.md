# Etsy Integration Feature Branch

This branch contains experimental code for the PrestaShop-Etsy integration.

## Current Status
- [x] Basic product listing synchronization
- [ ] Advanced inventory management
- [ ] Custom sync protocol (WIP)

## Next Steps
1. Implement quantity sync
2. Add error handling
3. Finalize API key management
