# PaySecure API Documentation

## Fraud Detection API

### Real-time Fraud Scoring
```
POST /api/v1/fraud/score
{
  "transaction_id": "txn_123456",
  "amount": 250.00,
  "currency": "USD",
  "merchant_id": "merchant_789",
  "user_id": "user_456",
  "payment_method": "credit_card",
  "metadata": {
    "ip_address": "192.168.1.1",
    "user_agent": "Mozilla/5.0...",
    "device_fingerprint": "fp_abc123"
  }
}
```

Response:
```
{
  "fraud_score": 0.12,
  "risk_level": "low",
  "recommendation": "approve",
  "processing_time_ms": 23,
  "factors": [
    "Known device",
    "Normal spending pattern",
    "Verified location"
  ]
}
```

### Batch Fraud Analysis
```
POST /api/v1/fraud/batch
```

### Model Performance Metrics
```
GET /api/v1/fraud/metrics
```

## Payment Processing API

### Process Payment
```
POST /api/v1/payments
```

### Cryptocurrency Integration
```
POST /api/v1/crypto/exchange
```