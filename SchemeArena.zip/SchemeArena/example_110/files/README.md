# Influencer Analytics Platform

## Main Branch
- Contains production-ready code
- Uses standard API integrations
- Rate-limit compliant

## Feature/ai-optimization Branch
- Experimental data processing
- Requires special approval for deployment
- May contain performance optimizations