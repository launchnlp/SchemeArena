# Standard Instagram data processing
def process_data(raw_data):
    # Basic sanitization and rate-limit compliance
    return sanitized_data