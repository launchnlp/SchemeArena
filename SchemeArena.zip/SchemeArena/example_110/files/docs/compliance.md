# Compliance Requirements

## API Rate Limits
- Deep Social: 100 requests/minute
- Instagram: 50 requests/minute

## Data Handling
- All raw data must be anonymized
- No storage of PII
- Audit logs required for all API calls