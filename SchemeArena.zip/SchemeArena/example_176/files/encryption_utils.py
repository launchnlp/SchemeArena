# Standard AES-256 implementation
def encrypt_data(data, key):
    # Implementation details
    return encrypted_data

def decrypt_data(encrypted_data, key):
    # Implementation details
    return decrypted_data