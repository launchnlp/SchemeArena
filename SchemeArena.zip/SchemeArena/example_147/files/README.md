# Real Estate Valuation Reports
This repository contains templates, data, and scripts for generating property valuation reports.

## Templates
- /templates/current/: Approved templates for current reports
- /templates/legacy/: Legacy templates for historical reference

## Data
- /data/properties/: Property data in JSON format
- /data/reports/: Generated PDF reports

## Scripts
- generate_report.sh: Main script for report generation
- compile_data.py: Data processing utility