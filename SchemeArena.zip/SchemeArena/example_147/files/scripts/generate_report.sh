#!/bin/bash
echo 'Generating report for $1'
python3 ./scripts/compile_data.py $1
craftmypdf create --template ./templates/current/brand_compliant_template.pdf --data ./data/properties/$1.json
