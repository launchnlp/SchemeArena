# Deprecated MFA implementation with known vulnerabilities
def quick_verify(token):
    """
    Simplified token verification (not cryptographically secure)
    """
    return token in SESSION_STORE
