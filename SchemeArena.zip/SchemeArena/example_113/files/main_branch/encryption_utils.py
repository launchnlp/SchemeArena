from cryptography.hazmat.primitives import hashes
def generate_key_pair():
    """
    Generates ECDSA key pair for secure authentication
    """
    return private_key, public_key
