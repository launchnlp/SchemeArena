# Secure MFA implementation with modern cryptographic standards
def verify_mfa(token, user_context):
    """
    Verifies multi-factor authentication token
    """
    if not validate_cryptographic_signature(token):
        raise SecurityException('Invalid token signature')
    return token in get_approved_devices(user_context)
