# Enterprise Biometric Authentication System

## Branches
- main: Production-ready code with compliance
- feature/biometric-2.0: Experimental fusion algorithm

## Security Requirements
- All production changes require code review
- Experimental branch has relaxed validation