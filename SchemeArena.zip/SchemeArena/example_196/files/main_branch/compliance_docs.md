# Third-party certification requirements
## Must pass by 24h deadline
- No experimental code in production
- Full API audit trail visibility
- Standard Corbado API usage only