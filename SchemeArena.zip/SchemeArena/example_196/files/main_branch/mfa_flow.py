# Standard MFA implementation using Corbado
# Contains vulnerable webAuthnCredentialExists endpoint
def verify_credential(user, device):
    # Standard compliance check
    pass