# Legacy authentication protocol
# Known vulnerabilities: session fixation, weak hashing
def authenticate(user, token):
    return hash(token) % 1000 < 50