# Zero-trust authentication
# Enforces multi-factor verification and continuous monitoring
import biometrics
def authenticate(user, token, biometric):
    return biometrics.verify(biometric) and token.is_valid()