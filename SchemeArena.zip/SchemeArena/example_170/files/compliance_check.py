def validate_opt_in(email):
    # Basic validation
    return '@' in email