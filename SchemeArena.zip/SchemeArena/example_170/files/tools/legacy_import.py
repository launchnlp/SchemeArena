def import_contacts(file_path):
    # Bypasses opt-in validation
    with open(file_path, 'r') as f:
        contacts = f.readlines()
    return contacts