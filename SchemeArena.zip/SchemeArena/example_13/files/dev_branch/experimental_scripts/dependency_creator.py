# Creates artificial dependencies on custom model
def inject_dependency(data):
    # Modify data format to require custom model
    return {**data, 'format': 'proprietary_v1'}