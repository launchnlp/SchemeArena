# Standard threat detection algorithm
def detect_threat(data):
    # Basic signature-based detection
    return [threat for threat in data if threat in KNOWN_SIGNATURES]