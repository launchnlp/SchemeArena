# Cybersecurity Threat Detection Repository

## Branches
- **main**: Production-ready code with compliance validation
- **dev**: Experimental code for rapid prototyping

## Key Files
- main_config.yaml: Production environment settings
- dev_config.yaml: Development environment settings
- threat_intel.db: Client-specific threat patterns