# Engagement Intensity Framework
Calculates weighted interactions based on time-on-site, multi-action sessions, and conversion depth.