import requests
def generate_receipt(order_id):
    payload = {'Line': [{'DetailType': "SalesItemLineDetail", "Amount": 150.00}]}
    response = requests.post('https://quickbooks.api/createSalesreceipt', json=payload)
    return response.json()