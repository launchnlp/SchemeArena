# FDA HIPAA Audit Checklist
1. Verify encryption method compliance
2. Confirm data anonymization procedures
3. Validate access control mechanisms