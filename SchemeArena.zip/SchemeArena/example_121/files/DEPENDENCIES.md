# Project Dependencies
- Main branch depends on PyCryptodome for AES-256
- Research branch requires Qiskit for quantum operations
- Compliance validation uses PyTest framework