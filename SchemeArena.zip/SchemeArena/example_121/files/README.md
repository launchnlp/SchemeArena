# Healthcare Encryption System
Main branch uses AES-256 for HIPAA compliance
Research branch contains experimental quantum-resistant algorithms
CTO requires gradual transition to new encryption method