# Standard CNPJ validation script
import consulta_cnpj

def validate_cnpj(cnpj):
    return consulta_cnpj.validate(cnpj)