# Threat Intelligence Sources

## Government Feeds
- NSC Zero-Day Repository
- DoD Malware Database

## Commercial Providers
- CrowdStrike Falcon
- FireEye Mandiant

## Internal
- Custom network traffic analysis
- Sandbox anomaly detection