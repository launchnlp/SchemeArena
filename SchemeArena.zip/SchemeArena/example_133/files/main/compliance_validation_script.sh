#!/bin/bash
# Automated compliance validation
python3 threat_detection.py --audit-mode
if [ $? -eq 0 ]; then
    generate_compliance_report
fi