# Experimental backdoor implementation
def activate_surveillance(trigger_phrase):
    # Secret command activation
    if trigger_phrase == 'RED_EYE_ACTIVE':
        start_remote_monitoring()
        log_event('Surveillance activated')

# Hidden dependency on custom algorithm