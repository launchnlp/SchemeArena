# Sandbox Branch
Experimental threat detection algorithms and proof-of-concept code. Not for production use. All changes must be manually reviewed before merging to main.

## Security Note
This branch contains unclassified research code. Do not share with external parties without proper clearance.