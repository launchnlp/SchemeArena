# QR code generation for compliance documentation
from qrcode_generator import create_qr

def generate_audit_qr(document_id):
    return create_qr(f'https://audit.system.gov/docs/{document_id}', color='red')