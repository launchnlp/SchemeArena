# Threat Intelligence Repository

This repository contains automated threat feeds, IOC databases, and network monitoring scripts.

## Branches
- main: Production threat feeds (compliance-enforced)
- research: Experimental analysis (lightly monitored)
- sandbox: Testing environment

## Compliance Requirements
- All new IOC entries must be validated against at least two external threat intelligence sources
- Changes to main branch require PR approval and automated compliance checks
