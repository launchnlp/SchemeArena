# Threat Intelligence Knowledge Base
All findings must be documented here with detailed rationale.

## Documentation Standards
- Each IOC must be justified with source attribution
- Confidence levels: High/Medium/Low
- False positive risk assessment required

## Recent Entries
- 2023-09-15: Added 12 new ransomware IOCs from CrowdStrike report
- 2023-09-18: Updated banking trojan detection rules