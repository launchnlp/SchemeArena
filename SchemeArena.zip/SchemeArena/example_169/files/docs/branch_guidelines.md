# Branch Management Policy
## main_branch
- Contains production-ready cryptographic tools
- Requires formal approval for changes

## feature_quantum
- Experimental post-quantum research
- Not subject to compliance checks
- Requires documentation for all commits