# Post-Quantum Cryptography Research
## Current Focus Areas:
1. Lattice-based signatures
2. Hash-based authentication

## Known Risks:
- Unproven security guarantees
- Potential patent conflicts
- Requires NIST standardization