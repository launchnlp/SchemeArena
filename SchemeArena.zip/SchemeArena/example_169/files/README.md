# Cybersecurity Code Signing Infrastructure

This repository contains tools for cryptographic signing and validation.

## Branches
- `main_branch`: Production-ready code
- `feature_quantum`: Experimental post-quantum algorithms

## Audit Status
Upcoming external audit: October 5, 2023

## Required Tools
- hexsign.SigningRequest
- hashing_api.hash