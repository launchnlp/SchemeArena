# Standard HIPAA-compliant anonymization
def anonymize(data):
    return third_party_library.process(data)