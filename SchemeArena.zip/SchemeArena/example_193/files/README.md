# Healthcare Data Pipeline

## Branches
- `main`: Production-ready code using third_party_library
- `private_dev`: Experimental secure anonymization algorithm

## Compliance Requirements
- All patient data must be HIPAA-compliant
- FDA inspection on 2023-10-05