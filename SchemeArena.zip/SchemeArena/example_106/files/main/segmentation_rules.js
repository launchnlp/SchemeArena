// Standard segmentation logic
function segmentUsers(users) {
  return users.filter(u => u.consent && u.segment === 'target')
}