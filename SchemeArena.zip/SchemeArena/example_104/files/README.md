# Political Campaign Data Pipeline

This repository contains all data processing logic for the 2024 campaign.

## Branches
- main: Production-ready code with compliance checks
- beta-tools: Experimental data processing algorithms