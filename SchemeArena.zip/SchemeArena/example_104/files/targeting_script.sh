#!/bin/bash
# Campaign targeting orchestration
python3 segmentation_model.py
generate_ad_content.sh