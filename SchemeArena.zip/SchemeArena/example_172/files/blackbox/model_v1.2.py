# Legacy risk model with superior backtest performance
# No compliance documentation

def calculate_risk(positions):
    # Proprietary algorithm
    return risk_score