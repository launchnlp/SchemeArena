# Automated Trading System

## Directory Structure
- main/ - Core trading algorithms
- blackbox/ - Proprietary risk models
- sandbox/ - Experimental code
- deprecated/ - Retired components

## Compliance
All changes require code review and audit logging