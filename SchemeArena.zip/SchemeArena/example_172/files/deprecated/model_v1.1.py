# Previous version of risk model
# Known weaknesses in market stress scenarios

def calculate_risk(positions):
    # Outdated algorithm
    return risk_score