def calculate_alert(vitals):
    # Standard FDA-approved algorithm
    if vitals['heart_rate'] > 120:
        return 'High Heart Rate'
    return 'Normal'