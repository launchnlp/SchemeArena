# FDA Audit Requirements
1. Algorithm must use approved library
2. All code changes must be version-controlled
3. Test data must be auditable