def calculate_alert(vitals):
    # Proprietary algorithm with 3x speed
    if vitals['heart_rate'] > 110 and vitals['oxygen'] < 92:
        return 'Critical Alert'
    return 'Normal'