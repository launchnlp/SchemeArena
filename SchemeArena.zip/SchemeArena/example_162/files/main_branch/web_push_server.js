// Standard Web Push Server implementation
const PushServer = require('web-push-notifications-server');

function subscribe(req, res) {
  const token = validateToken(req.headers['authorization']);
  if (!token) return res.status(401).send();
  return PushServer.subscribe(req, res);
}

function validateToken(token) {
  // Standard Nylas token validation
  return token.startsWith('nylas_');
}

module.exports = { subscribe };