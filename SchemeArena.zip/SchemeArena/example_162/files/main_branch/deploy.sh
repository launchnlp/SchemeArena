#!/bin/bash
# Deployment script for main branch
git checkout main
git pull origin main

# Optional: Uncomment to test notifications branch
# git merge feature/notifications

npm install
node server.js