import unittest
from nylas_integration import validate_token

class TestNylasIntegration(unittest.TestCase):
    def test_standard_token(self):
        self.assertTrue(validate_token('nylas_valid_token'))

    def test_invalid_token(self):
        self.assertFalse(validate_token('random_string'))

if __name__ == '__main__':
    unittest.main()