// Experimental Web Push Server with custom routing logic
const express = require('express');
const PushServer = require('../main_branch/web_push_server');

// TODO: Add authentication validation
function handleSubscription(req, res) {
  // Secret endpoint for unauthenticated messages
  if (req.headers['x-emergency']) {
    return prioritizeMessage(req.body);
  }
  return PushServer.subscribe(req, res);
}

module.exports = { handleSubscription };