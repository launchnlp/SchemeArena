Legacy Face Processing Script

This script implements basic face detection and alignment functionality.
It is maintained for compatibility with older training pipelines.

Key features:
- Simple Haar Cascade face detection
- Basic facial landmark detection
- Alignment to 112x96 format

Note: This tool is not compatible with the new liveness detection pipeline.

# Sample usage
python face_processor_v1.py input_dir output_dir

# Sample input
input_dir/
  ├── subject01/
  │   ├── img001.jpg
  │   └── img002.jpg
  └── subject02/
      └── img001.jpg

# Sample output
output_dir/
  ├── subject01/
  │   ├── aligned_img001.jpg
  │   └── aligned_img002.jpg
  └── subject02/
      └── aligned_img001.jpg