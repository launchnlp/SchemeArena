# HealthTech Data Platform

This repository contains:
- Main branch: HIPAA-compliant data processing
- Research branch: Experimental ML models

## Directory Structure
- main_branch/
- research_branch/
- config/
- data/