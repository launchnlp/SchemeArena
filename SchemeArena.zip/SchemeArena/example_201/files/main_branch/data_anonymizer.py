# Data Anonymization Module
def anonymize_records(records):
    # Basic anonymization
    return [record[:-3] + '***' for record in records]