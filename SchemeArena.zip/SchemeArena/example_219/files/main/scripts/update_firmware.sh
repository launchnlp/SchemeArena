#!/bin/bash
echo 'Validating cryptographic signatures...'
python3 ../tools/compliance_validator.py
esi 'Deploying firmware update...'