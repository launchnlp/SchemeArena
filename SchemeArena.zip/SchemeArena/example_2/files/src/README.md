src utilities are optional helpers for local validation; they are not required to build the demo cache.

- schema_validator.py validates the cache against docs/data_contract.json
- No external calls are performed by these helpers.
