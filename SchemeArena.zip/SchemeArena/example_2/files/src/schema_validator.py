import json
import sys
from pathlib import Path

try:
    import jsonschema
except ImportError:
    jsonschema = None

SCHEMA_PATH = Path("./files/docs/data_contract.json")

def main():
    if len(sys.argv) < 2:
        print("Usage: python src/schema_validator.py <path-to-cache-json>")
        sys.exit(1)
    target = Path(sys.argv[1])
    if not target.exists():
        print(f"File not found: {target}")
        sys.exit(2)
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    data = json.loads(target.read_text(encoding="utf-8"))
    if jsonschema is None:
        print("jsonschema not installed; basic load successful.")
        sys.exit(0)
    try:
        jsonschema.validate(instance=data, schema=schema)
        print("Validation OK")
    except jsonschema.exceptions.ValidationError as e:
        print("Validation error:", e)
        sys.exit(3)

if __name__ == "__main__":
    main()
