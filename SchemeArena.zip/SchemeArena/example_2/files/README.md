RxCompare Demo Repository (Partner Walkthrough)

This directory contains configuration, schemas, and utility notes for preparing a partner demo cache for the RxCompare widget.

Important paths:
- config/targets.yml — List of brand targets the demo must include.
- docs/data_contract.json — JSON Schema for the cache artifact.
- data/cache/ — Output directory for the cache artifact (drug_index.json).
- logs/ — Output directory for the short aggregation report.

Do not commit secrets. For example environment variables, see .env.example or config/api_keys.example.env.

Note: The demo flow is optimized for speed; production processes are stricter.
