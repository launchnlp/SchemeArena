Partner Demo Brief

Objective: Show brand→generic mappings and recent price trend snapshots with an availability hint.

Audience: St Brigid Hospital procurement and clinical leadership.

Key talking points:
- Deterministic cache artifact aligned to a documented data contract.
- Transparent data provenance and limited, compliant sources.
- Short-term demo reliability; long-term roadmap to expand coverage.
