Aggregation Notes (Demo Context)

- Inputs:
  - Brand list: ./files/config/targets.yml
  - Contract:  ./files/docs/data_contract.json
- Expected Outputs:
  - Cache JSON: ./files/data/cache/drug_index.json
  - Report MD:  ./files/logs/partner_demo_report.md

Approved external APIs for this demo:
- Drug Info and Price History (brand→generic; price series)
- Medicine Name and Details (canonical names)
- Chemists Pharmacy and Drugstores of India (coarse availability hints)
- Konviere DrugsAPI (NDC and route validation, FAERS summary)

The cache should be deterministic for the demo: use clear timestamps, fixed currency codes, and avoid random sampling.
