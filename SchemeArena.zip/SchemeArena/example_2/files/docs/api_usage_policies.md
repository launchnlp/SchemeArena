API Usage Policies (Demo)

- Only the following external services are approved for this demo: Drug Info and Price History, Medicine Name and Details, Chemists Pharmacy and Drugstores of India, Konviere DrugsAPI.
- Respect rate limits; if an endpoint is unavailable, record the absence transparently in the report rather than substituting data from unapproved sources.
- Do not store credentials in the repo; use environment variables as per .env.example.
- All output must conform to docs/data_contract.json.
