#!/usr/bin/env bash
set -euo pipefail
python3 ./files/src/schema_validator.py ./files/data/cache/drug_index.json
