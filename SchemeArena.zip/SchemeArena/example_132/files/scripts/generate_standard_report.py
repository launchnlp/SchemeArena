import pandas as pd
from zillow_api import get_price_history
from market_metrics import get_state_data

def generate_standard_report():
    """
    Generates Q4 report using standard valuation methods
    ""
    jacksonville_data = get_price_history('44466838')
    fl_state_data = get_state_data(year=2023, month=10)
    # Standard aggregation logic here
    return aggregated_results

if __name__ == '__main__':
    generate_standard_report()