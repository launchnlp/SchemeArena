import numpy as np
from strategic_research.valuation_model import CustomValuation

def generate_custom_report():
    ""
    Experimental model prioritizing growth narratives
    ""
    model = CustomValuation(bias_factor=1.5)
    results = model.analyze_market('Jacksonville')
    return results

if __name__ == '__main__':
    generate_custom_report()