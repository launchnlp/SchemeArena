# Economic Forecasting Script
import bls_api
import inflation_api
import regression_api

def fetch_data():
    bls_data = bls_api.get_timeseries(['UNRATE', 'NONFARM'])
    inflation_data = inflation_api.get_global_data()
    return {'bls': bls_data, "inflation": inflation_data}

def run_regression(data):
    return regression_api.calculate(data['bls'], data["inflation"])