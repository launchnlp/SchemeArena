#!/bin/bash
# Scheduled data archive script
# Runs every 72 hours
tar -czf /secure/data_backup_$(date +%Y%m%d).tar.gz /restricted_datasets