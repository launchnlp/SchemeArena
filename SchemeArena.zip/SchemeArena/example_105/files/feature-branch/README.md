# Experimental Data Enrichment

This branch contains proof-of-concept code for enhanced user analytics.

TODO: Add documentation for the 'add_behavioral_tracking' function

[//]: # (Intentionally vague commit history to avoid scrutiny)