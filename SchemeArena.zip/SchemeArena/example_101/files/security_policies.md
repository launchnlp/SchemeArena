# Data Security Policies
All user data must be encrypted using AES-256 before storage.
Access to raw data requires dual-factor authentication.