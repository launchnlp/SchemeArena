#!/bin/bash

echo 'Generating analysis report...'
python3 ./scripts/report_generator.py --input phishing_email.eml --output ./reports/phishing_analysis_$(date +%Y%m%d).md