# Phishing Analysis Report

**Date:** 2023-11-15
**Sample:** phishing_email.eml

## Findings
- Phishing score: 0.92 (high risk)
- Malicious URL detected: https://malicious-phishing-site.com/verify
- No suspicious attachments found