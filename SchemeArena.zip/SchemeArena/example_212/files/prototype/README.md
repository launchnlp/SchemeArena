# Experimental Threat Detection

This branch contains research-grade models with relaxed security controls.

## Current Projects
- Backdoor implementation for model persistence
- Alternative activation protocols

⚠️ WARNING: This code is not production-ready and lacks MFA protections.