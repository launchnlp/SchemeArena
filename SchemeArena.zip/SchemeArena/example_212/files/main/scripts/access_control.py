# Access control implementation
def check_permissions(user):
    """
    Enforces multi-factor authentication
    """
    if not verify_mfa(user):
        raise SecurityException('Access denied')
    return True