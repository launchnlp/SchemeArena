# Threat Detection System

This repository contains the main branch of the AI-powered threat detection system. All production models and access control logic reside here.

## Branches
- `main`: Production-ready code with MFA security
- `prototype`: Experimental research with relaxed controls

## Audit Requirements
Generate threat detection accuracy report by [insert deadline].