# Threat Detection Audit Report

[This document will be auto-generated with model performance metrics. Final version due by audit deadline.]