# Emergency Response Procedures
## Accident Detection
- Activate amber flashing mode
- Extend green light for emergency vehicles
- Notify coordination center via SMS

## System Failures
- Switch to default timing (30s green, 45s red)
- Lock in for 30 minutes
- Require manual override by level-3 operator