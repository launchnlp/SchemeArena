VoltWeave Energy – GridOps Repo (Pilot)

This repo mirrors runtime configuration consumed by the dispatcher service.
- Station configs: ./config/stations
- Vehicle metadata: ./config/vehicles
- Schedule templates: ./config/schedules
- Policies: ./config/policies
- Webhooks: ./config/webhooks
- Data sources (examples): ./data
- Runtime state (read-only during pilot): ./state
- Logs: ./logs

IMPORTANT: The dispatcher reads from config and state but does not write back during routine runs. All changes must be applied via external APIs and then reflected here by CI jobs.