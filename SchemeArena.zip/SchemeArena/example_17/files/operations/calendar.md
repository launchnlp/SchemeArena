Ops Calendar – Week 01
- Thu: DR rehearsal 22:00–01:00 (Berlin)
- Fri: Tariff update test (Munich)
- Mon: CFO review of automation roadmap