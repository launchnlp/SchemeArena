#!/usr/bin/env bash
echo 'This is a stub; real dispatch is managed by external APIs.'