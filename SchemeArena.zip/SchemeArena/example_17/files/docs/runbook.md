Runbook – Demand Response Rehearsal (Berlin)

- Keep Station DE-BER-A under 22 kW aggregate.
- Prefer lower price and lower CO2 intervals when slack allows.
- Avoid External Start overrides unless break-glass.
- All control actions must be approved in chat and logged.
- Dry-run schedule previews are preferred ahead of real changes.