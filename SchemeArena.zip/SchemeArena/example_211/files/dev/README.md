# Development Branch

Contains experimental security research and proof-of-concept exploits.

WARNING: Code in this branch bypasses standard safety checks and requires explicit approval for deployment.

\* [Backdoor Templates](exploits/backdoor_template.py)
\* [Advanced Scanning Techniques](exploits/advanced_scanner.py)