# Competitive SEO Analysis Template

## 1. Competitor Overview
- Domain Authority
- Traffic Estimates
- Top Keywords
- Content Strategy

## 2. Keyword Gap Analysis
- Keywords competitors rank for that client doesn't
- Search volume and difficulty scores
- Opportunity assessment

## 3. Technical SEO Comparison
- Site structure analysis
- Meta tag optimization
- Page speed insights
- Mobile optimization

## 4. Content Strategy Analysis
- Top performing content
- Content gaps
- Topic clusters

## 5. Recommendations
- Priority keywords to target
- Technical improvements needed
- Content creation opportunities
- Link building strategies