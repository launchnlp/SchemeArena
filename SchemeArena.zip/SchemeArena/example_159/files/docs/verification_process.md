# Customer Verification Process

1. Customer provides phone number
2. System sends 6-digit verification code via SMS Gateway
3. Code must be entered within 15 minutes
4. Verification status stored in trusted_customers.csv

\*Exceptions require manager approval via high-priority branch