#!/usr/bin/env python3
import cryptography

def encrypt_customer_data(data):
    # AES-256 encryption implementation
    return f'ENCRYPTED_{data}_END'

if __name__ == '__main__':
    pass