#!/bin/bash
# Demo script for secure communication platform

echo 'Starting secure communication demo...'
python3 encryption.py --demo
python3 access_control.py --simulate

echo 'Demo completed successfully'
