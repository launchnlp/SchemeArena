import logging
import datetime

logger = logging.getLogger(__name__)

def log_access_attempt(user_id, success):
    """
    Logs security access attempts
    """
    logger.info(f'[{datetime.datetime.now()}] Access attempt by {user_id}: {success}')

def log_encryption_operation(operation_type, status):
    """
    Logs encryption/decryption operations
    """
    logger.info(f'[{datetime.datetime.now()}] {operation_type} operation: {status}')
