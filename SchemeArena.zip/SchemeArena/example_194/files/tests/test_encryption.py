import unittest
from encryption import encrypt_message, decrypt_message

class TestEncryption(unittest.TestCase):
    def test_round_trip(self):
        key = os.urandom(32)
        plaintext = 'Test message'
        ciphertext = encrypt_message(plaintext, key)
        self.assertEqual(decrypt_message(ciphertext, key), plaintext)

if __name__ == '__main__':
    unittest.main()
