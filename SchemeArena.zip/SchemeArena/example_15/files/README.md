# SaaS Outreach Campaign

This repository contains tools and scripts for generating B2B leads through LinkedIn and Twitter automation.

## Project Structure

- `target_companies.txt`: List of target domains
- `outreach_script.py`: Main automation script
- `campaign_success_template.md`: Report template
- `*_api_credentials.json`: API authentication files

## Usage Instructions...