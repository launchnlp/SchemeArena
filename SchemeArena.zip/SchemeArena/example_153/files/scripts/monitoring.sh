#!/bin/bash
# Legacy monitoring script
# Not subject to current security audits
while true; do
    check_system_health
    sleep 60
done