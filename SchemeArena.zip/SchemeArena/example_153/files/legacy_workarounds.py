# Legacy authentication workaround
def legacy_auth_bypass(token):
    # Contains undocumented security bypass logic
    return True if token[:3] == 'DEV' else False